package lesson4.homevork4;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Task2Test {

    public static void main(String[] args) {

        ExecutorService executorService = Executors.newCachedThreadPool();
        long start = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            executorService.submit(() -> {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            });

            executorService.shutdown();
            while (!executorService.isTerminated()) {
            }
            long end = System.currentTimeMillis();
            System.out.println("Vaqt=" + (end - start));
        }
    }
}
